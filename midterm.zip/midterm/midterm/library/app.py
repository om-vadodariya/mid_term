from flask import Flask, render_template
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///library.db'
db = SQLAlchemy(app)

class Book(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(100), nullable=False)
    author = db.Column(db.String(100), nullable=False)
    price = db.Column(db.Float)
    year = db.Column(db.Integer)

@app.route('/')
def home():
    return render_template('home.html', books=Book.query.all())

@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/contact')
def contact():
    return render_template('contact.html')

@app.route('/author/<name>')
def author(name):
    return render_template('author.html', name=name, books=Book.query.filter_by(author=name).all())

with app.app_context():
    db.create_all()
    if Book.query.count() == 0:
        db.session.add_all([
            Book(title='Python Basics', author='John', price=250.0, year=2020),
            Book(title='Flask Guide', author='Mary', price=300.0, year=2021),
            Book(title='SQL Made Easy', author='John', price=199.5, year=2019),
        ])
        db.session.commit()

if __name__ == '__main__':
    app.run(debug=True)
